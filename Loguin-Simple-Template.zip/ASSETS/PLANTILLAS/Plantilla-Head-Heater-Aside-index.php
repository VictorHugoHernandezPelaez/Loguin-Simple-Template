<!DOCTYPE html>
<!--Esta página tenemos diseñada la plantilla donde se encuentra el Body-Head y Header.-->
<html>
	<head>
		<title>SIE</title>
		<meta charset="utf-8">
		<link rel="shortcut icon" type="text/css" href="ASSETS/IMG/estudiantes.png">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="ASSETS/CSS/css.css">
		<script language=”Javascript” src=”script.js” ></script>

	</head>
	<!--Sección Body-->
	<body>
	<div id="Body-css">
		<!--Sección Header-->
		<HEADER>
			<div class="Header-css">
				<br><br>
				<center><h2>LOGUIN</h2></center>
				<br><br>
			</div>
				<!--En esta sección tenemos los botones de las opciones para redirigir a las diferentes páginas.-->
			<div class="Aside-css">
				<center>
					<br>
					<h3>Sistemas de Información Empresariales.</h3>	
					<br>				
					<br><img class="Imagenes_Base" src="ASSETS/IMG/logocotecnova.png" alt="Imagen Corporativa del SENA."/>
					<br/>
					<br/>
					<br/>
					<br/>
				</center>
			</div>
		</HEADER>


			
			